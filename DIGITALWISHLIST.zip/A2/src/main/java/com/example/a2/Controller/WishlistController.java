package com.example.a2.Controller;

import com.example.a2.Model.Wishlist;
import com.example.a2.Repository.WishlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class WishlistController {

    /*@Autowired
    private WishlistService wishlistService;
*/

    @Autowired
    private WishlistRepository wishlistRepository;

@GetMapping("/")
//    @RequestMapping("/")
    public String homepage(Wishlist wishlist,Model model){
//        wishlistRepository.save(wishlist);
    model.addAttribute("wish",new Wishlist());

    return "index";
    }


    /*@RequestMapping ("/newwish")
    public String newWish(Wishlist wishlist){
        wishlistRepository.save(wishlist);
        return "new_wish";

    }*/




//    @GetMapping ("/newwish")

    public String newWish(Model model,Wishlist wishlist){
//        model.addAttribute("wish",new Wishlist());

        wishlistRepository.save(wishlist);

        return "new_wish";

    }
   /* @PostMapping("/process_wish")
    public String processWishes(Wishlist wishlist){
        wishlistRepository.save(wishlist);
        return "wish_success";
    }*/



}
